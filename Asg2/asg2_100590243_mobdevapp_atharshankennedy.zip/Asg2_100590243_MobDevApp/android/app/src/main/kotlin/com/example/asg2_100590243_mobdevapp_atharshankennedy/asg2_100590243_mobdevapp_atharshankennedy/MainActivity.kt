package com.example.asg2_100590243_mobdevapp_atharshankennedy.asg2_100590243_mobdevapp_atharshankennedy

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
