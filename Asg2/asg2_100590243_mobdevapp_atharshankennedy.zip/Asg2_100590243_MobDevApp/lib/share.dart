import 'package:flutter/material.dart';

class s extends StatefulWidget {
  const s({ Key? key }) : super(key: key);

  @override
  State createState() => S();
}

class S extends State{
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Asg2 - Atharshan Kennedy 100590243'),
      ),
      body: ListView(
        children: <Widget> [Image.asset(
          'images/lake.jpg',
          width: 600,
          height: 240,
          fit: BoxFit.cover,),
          ElevatedButton(onPressed: () {Navigator.pop(context);}, child: const Text('Going Back To Main')),
          IconButton(onPressed: () {  showDialog(context: context, builder: (ctx) => const AlertDialog(title: Text("Google")));} , icon: const Icon(Icons.g_mobiledata)),
          IconButton(onPressed: () {  showDialog(context: context, builder: (ctx) => const AlertDialog(title: Text("Groups")));} , icon: const Icon(Icons.account_circle)),
          IconButton(onPressed: () {  showDialog(context: context, builder: (ctx) => const AlertDialog(title: Text("Others")));} , icon: const Icon(Icons.add_circle)),
        ],
      ),
    );
  }
}