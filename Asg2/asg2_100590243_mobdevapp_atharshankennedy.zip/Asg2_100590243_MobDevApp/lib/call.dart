import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_dialpad/flutter_dialpad.dart';
import 'package:numeric_keyboard/numeric_keyboard.dart';

class d extends StatefulWidget {
  const d({ Key? key }) : super(key: key);

  @override
  State createState() => D();
}

class D extends State{
  String txt = "";
  @override
  Widget build(BuildContext context){
    return Scaffold(
        appBar: AppBar(
          title: const Text('Asg2 - Atharshan Kennedy 100590243'),
        ),
        body: ListView(
          children: <Widget> [Image.asset(
            'images/lake.jpg',
            width: 600,
            height: 240,
            fit: BoxFit.cover,),
            ElevatedButton(onPressed: () {Navigator.pop(context);}, child: const Text('Going Back To Main')),
            Text(
              txt,
              selectionColor: Colors.black,
              textAlign: TextAlign.center,
              textDirection: TextDirection.ltr,
            ),
            NumericKeyboard(
              onKeyboardTap: KeyTap,
              textColor: Colors.black26,
              rightButtonFn: () {
                setState(() {
                  txt = txt.substring(0, txt.length - 1);
                  });
                },
              rightIcon: const Icon(
                Icons.backspace_outlined,
                color: Colors.blue,
              ),
              leftButtonFn: () {
                showDialog(context: context, builder: (ctx) => AlertDialog(
                  title: Text("Calling $txt"),
                ));
              },
              leftIcon: const Icon(
                Icons.wifi_calling_sharp,
                color: Colors.greenAccent,
              ),
            ),
          ],
        ),
    );
  }
   KeyTap(String value) {
    setState(() {
      txt = txt + value;
    });
  }
}