// Copyright 2018 The Flutter team. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.




import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import './call.dart';
import './route.dart';
import './share.dart';


void main() {
  runApp(
    MaterialApp(
        // Start the app with the "/" named route. In our case, the app will start
        // on the FirstScreen Widget
        initialRoute: '/',
        routes: {
          // When we navigate to the "/" route, build the FirstScreen Widget
          '/': (context) => const MyApp(),
          // When we navigate to the "/second" route, build the SecondScreen Widget
          '/second': (context) => const d(),
          // When we navigate to the "/third" route, build the ThirdScreen Widget
          '/third': (context) => const r(),
          // When we navigate to the "/forth" route, build the ForthScreen Widget
          '/forth': (context) => const s(),
        },
    ),
  );
}
class MyApp extends StatelessWidget {
  const MyApp({super.key});
  @override
  Widget build(BuildContext context) {
    Widget titleSection = Container(
      padding: const EdgeInsets.all(32),
      child: Row(
        children: [
          Expanded(
            /*1*/
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                /*2*/
                Container(
                  padding: const EdgeInsets.only(bottom: 8),
                  child: const Text(
                    'Oeschinen Lake Campground',
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
                Text(
                  'Kandersteg, Switzerland',
                  style: TextStyle(
                    color: Colors.grey[500],
                  ),
                ),
              ],
            ),
          ),
          /*3*/
          Icon(
            Icons.star,
            color: Colors.red[500],
          ),
          const Text('41'),
        ],
      ),
    );


    Color color = Theme.of(context).primaryColor;

    Widget buttonSection = Row(
      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
      children: [
        _buildButtonColumn(color, Icons.call, 'CALL',context),
        _buildButtonColumn(color, Icons.near_me, 'ROUTE',context),
        _buildButtonColumn(color, Icons.share, 'SHARE',context),
      ],
    );

    Widget textSection = const Padding(
      padding: EdgeInsets.all(32),
      child: Text(
        'Lake Oeschinen lies at the foot of the Blüemlisalp in the Bernese '
            'Alps. Situated 1,578 meters above sea level, it is one of the '
            'larger Alpine Lakes. A gondola ride from Kandersteg, followed by a '
            'half-hour walk through pastures and pine forest, leads you to the '
            'lake, which warms to 20 degrees Celsius in the summer. Activities '
            'enjoyed here include rowing, and riding the summer toboggan run.',
        softWrap: true,
      ),
    );

    return MaterialApp(
      title: 'Asg2 - Atharshan Kennedy 100590243',
      home: Scaffold(
        appBar: AppBar(
          title: const Text('Asg2 - Atharshan Kennedy 100590243'),
        ),
        body: ListView(
          children: [Image.asset(
            'images/lake.jpg',
              width: 600,
              height: 240,
              fit: BoxFit.cover,),
            titleSection,
          buttonSection,
            textSection,
          ],
        ),
      ),
    );

  }

  void press(String l, BuildContext context){
    switch(l){
      case 'CALL':{
        Navigator.pushNamed(context, '/second');
      }
      break;
      case 'ROUTE':{
        Navigator.pushNamed(context, '/third');
      }
      break;
      case 'SHARE':{
        Navigator.pushNamed(context, '/forth');
      }
      break;
      default:{
        print("hello");
      }
      break;
    }
  }

  Column _buildButtonColumn(Color color, IconData icon, String label, BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        IconButton(onPressed: () { press(label,context); } , icon: Icon(icon, color: color)),
        Container(
          margin: const EdgeInsets.only(top: 8),
          child: Text(
            label,
            style: TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.w400,
              color: color,
            ),
          ),
        ),
      ],
    );
  }
}