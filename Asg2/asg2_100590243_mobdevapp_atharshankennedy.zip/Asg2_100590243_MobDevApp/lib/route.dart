import 'package:flutter/material.dart';

class r extends StatefulWidget {
  const r({ Key? key }) : super(key: key);

  @override
  State createState() => R();
}

class R extends State{
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Asg2 - Atharshan Kennedy 100590243'),
      ),
      body: ListView(
        children: <Widget> [Image.asset(
          'images/lake.jpg',
          width: 600,
          height: 240,
          fit: BoxFit.cover,),
          ElevatedButton(onPressed: () {Navigator.pop(context);}, child: const Text('Going Back To Main')),
          Image.network('https://cdn1.matadornetwork.com/blogs/1/2017/09/Panoramic-view-of-Oeschinen-Lake-in-Kandersteg-Switzerland-during-sunset-Swiss-Alps-in-background.jpg'),
        ],
      ),
    );
  }
}